#include <device/map.h>

void init_disk() {
}
