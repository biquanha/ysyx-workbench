/* category data */

enum category {
#include "categories.cat"
};

extern enum category category(wint_t ucs);
